const Database = require('./Database');

module.exports = { Database };
