const logger = require('./Logger');

module.exports = logger;
